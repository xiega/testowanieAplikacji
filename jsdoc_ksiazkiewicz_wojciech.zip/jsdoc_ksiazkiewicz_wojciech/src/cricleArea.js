/**
 * oblicza pole kołą.
 * @param {number} radius - promien kola
 * @throws {Error} jak `radius` jest mniejszy lub rowny `zero`
 * @returns {number} zwraca pole koła
 * @author Wojciech Ksiazkiewicz 5D
 */

function calculateArea(radius) {
    if (radius <= 0) throw Error('');
    else return Math.pow(Math.PI*radius, 2)
}