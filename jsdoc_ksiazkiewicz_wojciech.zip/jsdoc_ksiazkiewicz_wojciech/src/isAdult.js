/**
 * sprawdza czy ktos jest dorosły.
 * @param {number} age - wiek do sprawdzenia
 * @throws {Error} jak `age` jest mniejszy rowny `zero`
 * @returns {boolean} zwraca true jezeli ktos ma wiecej lub rowno 18 lat
 * @author Wojciech Ksiazkiewicz 5D
 */

function isAdult(age) {
    if (age <= 0) throw Error('wiek nie moze byc dodatni wiekszy od 0');
    else {
        if (age < 18) return false;
        else return true;
    }
}