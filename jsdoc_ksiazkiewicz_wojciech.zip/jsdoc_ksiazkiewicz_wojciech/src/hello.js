/**
 * wita uzytkownika.
 * @param {string} somebody - imie osoby
 * @returns {string} zwraca `Hello` {imie osoby}
 * @author Wojciech Ksiazkiewicz 5D
 */

const sayHello = (somebody) => {
    alert(`Hello ${somebody}`);
};